# -------------------------------------------------------------------- #
#  Advanced course in R
#    Dataset ’assignment’
#
#
#  input:   assignment (.xlsx)
#  output:  assignment_prepared (.Rdata)
#
#  remarks: -
#  author:  SOLUTION
#  status:  19.03.2024
# -------------------------------------------------------------------- #

# clear workspace
  rm(list=ls(all=TRUE))

# general information about dataset version
date_received <- "20240305"
date_prepared <- "20240319"


# ------------------------- #
#  PATHS ----
# ------------------------- #

# paths relative to R project
  path_Rfiles <- "R/Rfiles/"
  path_Rdata <- "R/Rdata/"


# ------------------------- #
#  LIBRARIES ----
# ------------------------- #
# if you have not yet installed these packages via Tools -> Install Packages...
  
  library(tidyverse)
  library(ggplot2)
  library(readxl)


# ------------------------- #
#  FUNCTIONS ----
# ------------------------- #

# none here




# --------------------------------------------------------------------------- #
#  INPUT ----
# --------------------------------------------------------------------------- #
# ------------------------- #
##  file names input ----
# ------------------------- #

# name of data file in folder Rdata
  file_input <- "assignment_v20240305.xlsx"

# ------------------------- #
##  file names output ----
# ------------------------- #


# create output name for dataset
  file_output_rdata <- paste0("assignment_prepared_v", date_prepared, ".Rdata")




# --------------------------------------------------------------------------- #
#  INFORMATION GENERAL ----
# --------------------------------------------------------------------------- #

# It is good habit to keep track on information regarding the data set we use

info <- list()

## General information ----
info_general <-
    tibble(Topic = c("Original data file",
                     "Date original data received",

                     "Date prepared",
                     "File used for preparation",
                     "Current data file"
    ),

    Name = c(file_input,
             date_received,

             date_prepared,
             str_split(string = rstudioapi::getSourceEditorContext()$path,
                       pattern = "/", simplify = TRUE) %>% as.character %>% last(),
             file_output_rdata
    )
    )


info$general <- info_general


# --------------------------------------------------------------------------- #
#  DATA IMPORT ----
# --------------------------------------------------------------------------- #

  sheetname <- "Sheet 1"
  
  dt_assign <-
      readxl::read_xlsx(path = paste0(path_Rdata, file_input),
                        sheet = sheetname,
                        col_names = TRUE,
                        na = c(NA, "missing", "??"))



# --------------------------------------------------------------------------- #
#  DATA PREPARATION ----
# --------------------------------------------------------------------------- #

# check class of all parameters in dataset
  str(dt_assign)

# change data type and add labels to factors

  dt_assign <-
      dt_assign %>%
  
      # subject ID should be characters
      mutate(id = as.character(id),
             age = as.numeric(age)) %>%
  
      # change all categorical parameters to factors and add labels
      mutate(group = factor(group,
                            levels = c("A", "B", "C"),
                            labels = c("A", "B", "C")),
             gender = factor(gender,
                             levels = c(1, 2),
                             labels = c("female", "male")),
             blgrp = factor(blgrp,
                            levels = c(0, 1, 2, 3),
                            labels = c("0", "A", "B", "AB")),
             drug_use = factor(drug_use,
                                 levels = c("none", "aspirin", "beta blocker", "both"),
                                 labels = c("none", "aspirin", "beta blocker", "both")))



# check class of all parameters in dataset
 str(dt_assign)



# --------------------------------------------------------------------------- #
# Dictionary ----
# --------------------------------------------------------------------------- #

# sometimes detailed dictionary is available

  dictionary <-
      tibble(parameter = names(dt_assign),
             parameter_label = c("ID",
                                 "Medication",
                                 "Gender",
                                 "Age [years]",
                                 "Height [cm]",
                                 "Weight [kg]",
                                 "BMI",
                                 "Blood group",
                                 "HbA1c (%)",
                                 "collagen volume fraction (%)",
                                 "Drug use"
  
             ),
             parameter_info = c("Unique Identifier",
                                "A, B, C",
                                "1 female, 2 male",
                                "Age [years]",
                                "in cm",
                                "in kg",
                                "BMI",
                                "0 is 0, 1 is A, 2 is B, 3 is AB",
                                "HbA1c (%)",
                                "collagen volume fraction (%)",
                                "Drug use is grouped in none, aspirin, beta blocker,both")
      )
  
  info$dictionary <- dictionary

# --------------------------------------------------------------------------- #
# SAVE ----
# --------------------------------------------------------------------------- #
  
  save(
      # information about dataset
        info,
  
      # datasets
        dt_assign,
  
  
      # path & name where workspace is saved as Rdata
        file = paste0(path_Rdata, file_output_rdata)
  
  )



